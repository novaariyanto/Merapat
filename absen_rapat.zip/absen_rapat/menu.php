<nav class="bg-green-600 p-4">
    <div class="container mx-auto flex justify-between items-center">
        <a href="daftar_rapat.php" class="text-white font-bold text-xl">Aplikasi Absensi Rapat</a>
        <div class="space-x-4">
            <a href="daftar_rapat.php" class="text-white hover:text-green-200">Daftar Rapat</a>
            <!-- <a href="tambah_rapat.php" class="text-white hover:text-green-200">Tambah Rapat</a> -->
        </div>
    </div>
</nav>