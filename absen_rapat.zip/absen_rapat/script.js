// Simulasi kontrol suara (memerlukan SpeechRecognition API)
const voiceButton = document.getElementById('voice-button');

voiceButton.addEventListener('click', () => {
    alert('Kontrol suara tidak tersedia dalam simulasi ini.');
});